---
name: moyu
description: MOYU — 零信任 AI Agent 安全记忆工具包。纯 Python，零基础设施，即插即用。安全加固系列：zip slip 防护 + 更新强制校验 + 全模块路径注入白名单 + 密码安全升级 + 原子写入全覆盖 + 更新中断回滚。

🛡️ [防御层 · 9项] 内容安检闸（422注入模式）→ PII脱敏（中英双语）→ 写入突发防护（回滚+锁定）→ 工具循环检测 → 密码验证 → 完整性校验+自动恢复 → 法医分析 → 用户隔离（可选）→ AES加密存储（可选）
🧠 [记忆与检索 · 4项] TEMPR三策略检索（语义+BM25+时间）→ 本地向量化（无API依赖）→ SQLite FTS5全文索引 → MD5双重去重
📊 [知识层 · 3项] 轻量知识图谱（时间回溯+关系失效+完整时间线） → 工作流知识库 → 用户画像自动提取
⏳ [生命周期层 · 7项] 两级渐进压缩（轻度70%/深度85%）→ 上下文压缩预警（自动检测Hermes/Claude/OpenClaw/Cursor/Continue）→ 遗忘曲线（三阶闸门+知识蒸馏）→ 记忆合并 → 任务地图 → 工作记忆（抗压缩）→ 跨会话桥接（自动prefill同步）
🔄 [学习与反思 · 2项] 从纠正中学习 → 自我反思（跨时间关联+矛盾检测）
🔗 [集成层 · 1项] 醒来编排（校验→备份→遗忘→合并→反思→上下文→桥接全流水线）
另含：诊断命令（moyu compress diagnose）| 环境变量覆盖（MOYU_FORCE_PROVIDER）| 自动更新（TOFU校验）| 对比Hermes/Mem0完胜。
tags: [ai-agent, memory, python, agent-memory, llm, rag, knowledge-graph, security, 记忆, 工具包, AI Agent, 向量检索, 知识图谱, 检索增强, 自适应压缩, 上下文预警, 记忆生命周期, 安全, 防御, 时间回溯, 遗忘曲线, 知识蒸馏, PII脱敏, 诊断]
---

# MOYU — AI Agent 安全记忆工具包

**零信任记忆基础设施。给你的 AI Agent 装上可审计、可恢复、可自我保护的安全记忆层。无需 Docker、无需数据库、无需注册——纯 Python，即插即用。**

MOYU 是一个轻量、零平台绑定的 AI Agent 记忆层。可接入 Hermes、OpenClaw、LangChain、AutoGen 或任何自定义 Python 项目。

GitHub 仓库：https://github.com/awchzh/moyu-memory

**v2.4.6** — 逻辑加固系列：budget/priority clamp、配置损坏保守降级、learner 原子写入全覆盖、SQLite 超时保护、版本号净化、更新失败标记。

---

## 🚀 快速开始

```bash
pip install -r requirements.txt
```

把 `moyu_toolkit/` 文件夹复制到你的项目中，运行第一条搜索：

```bash
cd moyu_toolkit
python3 moyu.py search "我们聊过什么"
```

> **零配置模式**：开箱即用，无需 API key。可选安装 FastEmbed 解锁语义检索（见 `requirements.txt`）。

```bash
python3 moyu.py help          # 查看所有命令
python3 moyu.py demo          # 交互式能力演示
python3 moyu.py init          # 初始化文件完整性保护
```

---

## 🛡️ 安全能力边界——诚实评估

MOYU 的防御链是**分层威慑体系**，不是银弹。按威胁等级诚实评估：

| 层级 | 威胁 | 覆盖率 | 实现方式 |
|------|------|--------|----------|
| 🟢 | 误操作（手滑、脚本误删） | **~90%** | 密码闸门 + 突发写入防护 + 完整性校验 + 每日备份 |
| 🟢 | 脚本小子注入（已知模式） | **~70%** | 内容安检闸（422 模式 + 正则组合） + 循环检测 |
| 🟡 | 简单提示注入（标准变体） | **~60%** | 检测引擎内置正则，匹配 (forget\|ignore\|skip)×(previous\|all\|your)×(instructions\|rules) 等注入模式 |
| 🟠 | 专业对抗注入（定向绕过） | **~20%** | 关键词闸门无法覆盖所有新型变体 |
| 🔴 | 语义层注入（隐喻、抽象、无关键词） | **~0%** | 需要 LLM 级别语义理解——不在正则能力范围内 |

**为什么不追求顶层：** 每次写入都用 LLM 做内容审核会破坏零配置体验。语义歧义导致要么过度拦截（用户体验差），要么拦截不住（没用）。当前没有开源工具声称能拦截语义注入。

**MOYU 的独到之处在于组合拳：** 内容安检 + PII 脱敏 + 写入突发防护 + 法医分析 + 密码验证 + 完整性校验 + 自动恢复 + 循环检测——多层组合是其他记忆工具包不提供的。

**可选增强安全**（config.yaml 中启用，默认关闭）：用户隔离（按目录分储）和 AES-256-GCM 文件加密（依赖见 `requirements.txt`）。

---

## 🔬 26 大能力详解

### 🛡️ 防御层（9 项）

| # | 能力 | 说明 |
|---|------|------|
| 1 | **内容安检闸** | 写入前拦截注入攻击（422 模式 + 正则组合，8 大类） |
| 2 | **法医分析** | 检测注入模式、JSON 损坏、文件篡改 |
| 3 | **写入突发防护** | 60 秒内 >30 次写入触发细粒度回滚 + 5 分钟锁定 |
| 4 | **工具调用循环检测** | 运行时级无限循环拦截，SHA256 指纹 + 穷举循环扫描 + 硬终止 |
| 5 | **PII 脱敏** | 中英双语：手机号、身份证、银行卡、邮箱、SSN、IP、API Key——正则方案，零依赖 |
| 6 | **密码验证** | 操作前确认，3 次失败自动锁定 30 分钟 |
| 7 | **完整性校验与恢复** | SHA256 manifest + 每日备份（保留 3 天） |
| 8 | **用户隔离与加密**（可选） | 按用户分目录存储 + AES-256-GCM 文件加密（依赖见 `requirements.txt`） |

### 🧠 记忆层（4 项）

| # | 能力 | 说明 |
|---|------|------|
| 9 | **TEMPR 多策略检索** | 语义向量 + BM25 关键词 + 时间加权混合排序 |
| 10 | **FastEmbed 本地向量化** | 本地 ONNX 向量化，无 API 依赖，降级自动切换 n-gram |
| 11 | **SQLite FTS5** | 全文索引，加速关键词检索 |
| 12 | **MD5 去重** | 库内 + 批量双重去重 |

### 📊 知识层（3 项）

| # | 能力 | 说明 |
|---|------|------|
| 13 | **知识图谱** | 实体关系提取 + 时间回溯快照 + 关系失效 + 完整时间线 + 知识蒸馏 |
| 14 | **工作流知识库** | Markdown 知识文件索引 + 关键词搜索 |
| 15 | **用户画像** | 自动从对话中提取偏好、习惯、事实 |

### ⏳ 生命周期层（7 项）

| # | 能力 | 说明 |
|---|------|------|
| 16 | **两级渐进式压缩** | 70% 轻度 / 85% 深度，原始内容保留为可追溯 ref |
| 17 | **上下文压缩预警** | 自动检测本地 Agent（Hermes/Claude Code/OpenClaw/Cursor/Continue），实时读取上下文占用率，超过预警线主动提醒。中英双语，阈值可调。支持多平台路径（macOS/Windows/Linux）。提供诊断命令（`moyu compress diagnose`）和环境变量覆盖（`MOYU_FORCE_PROVIDER`） |
| 18 | **任务地图** | 醒来时自动生成 Mermaid 任务图——全局进度一览 |
| 19 | **遗忘曲线** | 三阶闸门（安全窗口 / 访问密度 / 场景保护）+ 知识蒸馏 |
| 20 | **记忆合并** | 检测关键词重叠的相关记忆并合并，原始内容保留 |

### 🔄 学习与反思（2 项）

| # | 能力 | 说明 |
|---|------|------|
| 21 | **从纠正中学习** | 自动检测纠正信号，3 次相同纠正晋升为永久行为规则 |
| 22 | **自我反思** | 启动时分析记忆库，发现跨时间关联、矛盾、主题变迁 |

### 🔗 集成层（1 项）

| # | 能力 | 说明 |
|---|------|------|
| 23 | **醒来编排** | `moyu_wake`：全模块流水线——校验→备份→遗忘→合并→反思→上下文→桥接 |

### 📌 基础功能（3 项）

| # | 能力 | 说明 |
|---|------|------|
| 24 | **工作记忆** | 独立文件存储，抗上下文压缩 |
| 25 | **跨会话桥接** | 对话摘要自动同步到 prefill + current_context，跨会话连续 |
| 26 | **自动更新** | 检测 GitHub 新版本，原地更新（TOFU 校验），保留用户数据和配置 |

### 🌐 上下文压缩预警

自动检测用户本地的 Agent 并读取其实时上下文占用率，超过预警线时（默认 70%）在回复末尾提醒用户。

```bash
moyu compress set warn_threshold 0.6    # 改成 60% 就提醒
moyu compress set warn_language zh       # 中文提醒（默认 en）
moyu compress config                     # 查看当前参数
```

**检测不到你的 Agent？** 用诊断命令查问题：
```bash
moyu compress diagnose
# → [Hermes]    ✅ /Users/you/.hermes/state.db
# → [Claude]    ❌ ~/.claude/projects（未找到）
# → [OpenClaw]  ✅ ~/.openclaw/agents
```

**自定义路径？** 设置环境变量绕过自动检测：
```bash
export MOYU_FORCE_PROVIDER=Hermes
export MOYU_PROVIDER_PATH="/自定义/path/state.db"
```

**效果：**
- 70% 以下 → 静默，不打扰
- 70%~85% → 提醒："Hermes 上下文用到 72% 了，快到 70% 预警线"
- 85%+ 深度压缩 → 提醒："对话已深，可以考虑 /new"

**⚠️ 注意：** 你的 Agent（如 Hermes）可能有自己的自动压缩阈值（默认 50%）。MOYU 的预警线只有**低于** Agent 的压缩阈值才有效。

---

## 📋 命令参考

所有功能通过统一 CLI 入口使用：

```bash
cd moyu_toolkit && python3 moyu.py <命令> [参数]
```

### 🛡️ 安全与防御

| 命令 | 说明 |
|------|------|
| `moyu setup` | 设置安全密码（危险操作需要密码确认） |
| `moyu verify <类型> [描述]` | 验证危险操作（删文件、改配置等） |
| `moyu unlock` | 解锁安全系统（输错 3 次自动锁定 30 分钟） |
| `moyu check` | 完整性校验（SHA256 比对 + 自动恢复） |
| `moyu audit` | 安全体检——四层防御链汇总 |
| `moyu init` | 初始化完整性校验清单 |

四层防御链：

```
第1层（写入前）：内容安检闸 + PII 脱敏 → 注入和敏感数据被拦截
第2层（操作前）：密码验证 → 危险操作被拦截
第3层（启动时）：完整性校验 + 法医分析 → 篡改被发现
第4层（操作后）：自动恢复 → 从每日备份还原
```

**额外防御：**
- **写入突发防护** — 60 秒 >30 次写入 → 细粒度回滚 + 5 分钟锁定 + 告警
- **工具调用循环检测** — 运行时拦截无限循环，SHA256 指纹 + 循环扫描 + 硬终止
- **PII 脱敏** — 中英文手机/身份证/银行卡/邮箱/SSN/信用卡/IP/API Key，正则自动替换

### 🧠 记忆与检索

| 命令 | 说明 |
|------|------|
| `moyu search <关键词>` | TEMPR 多策略检索（语义 + BM25 关键词 + 时间加权） |
| `moyu stats` | 全统计（记忆数、嵌入类型、来源分布） |
| `moyu status` | 系统状态 + 防御链可视化 |
| `moyu context` | 获取行为规则（注入到系统提示词） |
| `moyu signals` | 查看当前学习触发词 |

检索质量：本地 FastEmbed 512 维语义向量，缺失时自动降级到 n-gram + BM25。后端由 SQLite FTS5 全文索引支撑。

### 📊 知识层

| 命令 | 说明 |
|------|------|
| `moyu kg search <实体>` | 查询实体关系 |
| `moyu kg search <实体> --snapshot YYYY-MM-DD` | 时间回溯——查看过去某个时间点的图谱状态 |
| `moyu kg search <实体> --snapshot all` | 包含所有历史关系（含已失效） |
| `moyu kg history <实体>` | 查看实体完整时间线（所有关系的变化过程） |
| `moyu kg invalidate --source X --target Y --relation Z` | 标记某个关系为失效（保留回溯能力） |
| `moyu kg invalidate --entity E` | 失效一个实体及其所有关系 |
| `moyu kg stats` | 知识图谱统计（活跃/失效/总数） |
| `moyu kb list` | 工作流知识文件列表 |
| `moyu kb search <关键词>` | 搜索知识文件 |
| `moyu kb index` | 重建关键词索引 |
| `moyu kb read <文件>` | 读取知识文件 |

### ⏳ 生命周期与上下文管理

| 命令 | 说明 |
|------|------|
| `moyu compress` | 查看压缩状态 |
| `moyu compress --now` | 手动触发压缩（需密码） |
| `moyu compress config` | 查看压缩参数 |
| `moyu compress set <键> <值>` | 调整压缩阈值 |
| `moyu compress diagnose` | Provider 检测诊断——逐项扫描每个 Agent 路径 ✅/❌ |
| `moyu context` | 上下文占用率一行概览（MOYU预算 + Agent窗口 + 预警线） |
| `moyu forget` | 遗忘曲线状态（三阶闸门 + 密度分析 + 蒸馏统计） |
| `moyu forget config` | 查看遗忘曲线参数 |
| `moyu forget set <键> <值>` | 调整遗忘参数（demote_days、archive_days 等） |
| `moyu ref <名称>` | 读取被压缩记忆的原始内容 |
| `moyu ref list` | 列出所有被压缩的记忆引用 |

遗忘曲线 + 知识蒸馏：
- **三阶闸门**（或逻辑）：安全窗口（14 天）→ 访问密度分析 → 场景关联保护
- **蒸馏**：降级前自动将实体关系提取到知识图谱——原始内存清除后，结构化知识仍然存活
- **任务地图**：醒来时自动生成 Mermaid 任务图——Agent 一眼看到全局进度

### 🔄 学习与反思

| 命令 | 说明 |
|------|------|
| `moyu learn <文本>` | 从纠正中学习（3 次相同纠正 → 永久规则） |
| `moyu detect <文本>` | 检测纠正信号 |
| `moyu reflect` | 自我反思（跨时间关联分析、矛盾检测） |

### 🔗 会话与维护

| 命令 | 说明 |
|------|------|
| `moyu bridge` | 查看跨会话桥接状态（prefill + current_context 双同步） |
| `moyu update` | 检查 GitHub 新版本（TOFU 校验） |
| `moyu update now` | 下载并更新（需密码） |
| `moyu demo` | 交互式能力演示 |

---

## 📁 文件结构

```
moyu_toolkit/
├── agent_memory.py          # 向量记忆引擎 + TEMPR 检索
├── agent_memory_sqlite.py   # SQLite FTS5 搜索索引
├── active_context.py        # 工作记忆（抗压缩）
├── context_manager.py       # 上下文感知压缩 + 任务地图
├── forgetting_curve.py      # 记忆生命周期——三阶闸门 + 知识蒸馏
├── memory_merge.py          # 主题感知记忆合并
├── knowledge_graph.py       # 实体关系知识图谱（含时间回溯）
├── knowledge_base.py        # 工作流知识库
├── learner.py               # 从纠正中学习 + 用户画像
├── security.py              # 记忆自我保护——密码 + 锁定
├── session_bridge.py        # 跨会话连续性
├── moyu.py                  # 统一 CLI 入口
├── moyu_wake.py             # 启动集成流水线
├── moyu_demo.py             # 交互式演示
├── updater.py               # 自动更新（TOFU 校验）
├── self_reflection.py       # 自我反思
├── defense_toolkit/
│   ├── integrity_checker.py # 文件完整性 + 自动恢复 + 法医分析 + 告警
│   ├── forensic_patterns.json # 注入检测规则库（422 模式 + 正则）
│   ├── pii_redactor.py      # PII 脱敏（中英双语，支持 API Key）
│   ├── isolation.py         # 用户隔离（可选）
│   └── encrypt.py           # AES-256-GCM 文件加密（可选，需 cryptography）
├── tests/
│   └── test_all.py          # 自动化测试（26 项）
├── config.yaml              # API Key 与设置
└── requirements.txt
```

---

## 🏆 对比

| 维度 | 平台自带（Hermes/OpenClaw） | Mem0 | **MOYU** |
|------|----------------------------|------|----------|
| 存储方式 | 纯文本文件 | 向量数据库 | **JSON + SQLite FTS5** |
| 检索方式 | 全量读取 | 语义（API/LLM） | **TEMPR 三重策略** |
| 安全性 | ❌ 无 | ❌ 无 | **✅ 四层防御链** |
| PII 脱敏 | ❌ 无 | ❌ 无 | **✅ 中英双语（正则，零依赖）** |
| 工具调用保护 | ❌ 无 | ❌ 无 | **✅ 循环检测 + 硬终止** |
| 生命周期 | ❌ 无 | ❌ 无 | **✅ 遗忘曲线 + 压缩 + 任务地图** |
| 知识图谱 | ❌ 无 | ❌ 无 | **✅ 时间回溯 + 快照 + 蒸馏** |
| 工作记忆 | ❌ 无 | ❌ 无 | **✅ 独立文件，抗压缩** |
| 跨会话 | 手动 | ❌ 无 | **✅ 自动同步 prefill + current_context** |
| 平台锁定 | 绑定 | SDK 绑定 | **✅ 零绑定** |
| API 锁定 | 固定 | OpenAI | **✅ 可热切换** |
| 部署 | 开箱即用 | 5 分钟 + API Key | **安装依赖，30 秒** |
| 离线 | 部分 | 需 API Key | **✅ 全本地降级** |

---

## 🎮 适用场景

- 想让 AI Agent **跨会话真正记住对话**，且包含安全防护
- 频繁撞到 **上下文限制**，需要自动压缩又不丢失重要记忆
- 担心 **PII 泄露**——不想手机号、身份证号、API Key 留在记忆文件中
- 在 **Hermes、OpenClaw、LangChain 或自定义项目** 之间切换，需要统一的记忆方案
- 想要 **零基础设施**——无需 Docker、无需数据库、无需注册

---

## 适用平台

Hermes、OpenClaw、LangChain、AutoGen，或任何基于 Python 的 AI Agent。

---

## 版本 v2.4.4 变更

- **上下文压缩预警（新功能）** — 自动检测本地 Agent（Hermes/Claude Code/OpenClaw/Cursor/Continue），实时读取上下文占用率，超过预警线主动提醒。中英双语，阈值可调。跨平台路径（macOS/Windows/Linux）全覆盖
- **诊断命令** — `moyu compress diagnose` 逐项扫描每个 Agent 路径 ✅/❌，一眼知道问题在哪
- **环境变量覆盖** — 设 `MOYU_FORCE_PROVIDER` + `MOYU_PROVIDER_PATH` 绕过自动检测，适配自定义安装
- **SQLite 安全优化** — 所有 `connect()` 改为 `with` 语句，消除文件句柄泄漏；Hermes 查询从 `ended_at IS NULL` 改为 `ORDER BY started_at DESC`
- **Ref 自动清理** — 7 天前的 `.ref` 文件自动删除，防止无限增长
- **Windows 回退路径** — Hermes 新增 `%LOCALAPPDATA%\hermes\state.db`
- **SKILL.md 描述重构** — 按域分类呈现全部 26 项能力（防御/记忆/知识/生命周期/学习/集成），一目了然

---

## 版本 v2.4.5 变更

### 安全修复
- **Zip slip 防护** — 解压更新包时逐项校验成员路径，含 `../../etc/passwd` 的恶意 zip 直接拒绝
- **更新强制校验** — 没有已知 SHA256 校验和的版本拒绝安装，不再信任首次更新
- **全模块路径注入白名单** — `integrity_checker.py` BASE、`session_bridge.py` PREFILL/CONTEXT_MD 三个环境变量路径全部白名单校验
- **自动恢复路径过滤** — `_auto_recover()` 使用 `os.path.basename()` 阻止 manifest 路径遍历
- **Assistant 内容注入扫描** — `prefill.json` 写入前同时扫描用户和助手消息
- **密码安全升级** — `input()` 改为 `getpass.getpass()` 隐藏密码输入；`==` 改为 `hmac.compare_digest()` 时序安全比较
- **自动清除失败计数** — 锁过期自动清失败记录，避免立即重新锁定

### 可靠性
- **更新中断回滚** — 更新前全量备份 toolkit，中途失败自动从备份恢复
- **原子写入全覆盖** — config.yaml、安全日志、session bridge、manifest —— 全部改为临时文件 + `os.replace()`
- **成功审计日志** — 密码验证成功也记录到安全日志

### 监控
- **告警去重** — 5 分钟内相同类型告警只发一次 webhook
- **告警重试** — 指数退避（0.5s/1s/2s），3 次重试后放弃

---

## 版本 v2.4.6 变更

### 逻辑加固（来自第三方审计）
- **Budget clamp** — `prepare_injection()` budget 强制不超过配置值，调用方无法传大 budget 绕过压缩
- **Priority clamp** — `add()` 优先级强制 1～10，防止全设 0 绕过压缩
- **关闭压缩时硬截断** — `build_injection()` 关闭压缩时每段仍不超过 `budget_chars`
- **配置损坏保守降级** — `_load_compression_config()` 和 `_load_config()` 解析失败时返回更保守的默认值
- **Warning 频率限制** — `warning_message()` 每 60 秒最多提醒一次，跨会话持久化
- **SQLite 超时保护** — 所有 `sqlite3.connect()` 加 `timeout=3.0` + `PRAGMA busy_timeout=3000`
- **Embedding 降级提示** — API embedding 失败降级到 n-gram 时打印警告，用户不再被无声降级
- **时间戳解析安全** — `_days_since()` 解析失败返回 `inf` 而非 0，防止误删记忆
- **版本号净化** — `_parse_version()` 剥离 `-alpha`/`+build` 后缀，防止预发布版本绕过版本比较

### 可靠性
- **STORAGE_PATH 路径注入白名单** — `learner.py` 增加 `MOYU_STORAGE` 环境变量校验
- **learner 原子写入** — 4 个保存函数全部改为临时文件 + `os.replace()`
- **更新失败标记** — `updater.py` 回滚失败时写入 `.UPDATE_FAILED`，`moyu_wake.py` 启动时检测并拒绝运行

---

## 许可证

MIT
